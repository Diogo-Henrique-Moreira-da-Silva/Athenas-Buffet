function publicarVaga() {
    alert("Vaga publicada com sucesso!");
}